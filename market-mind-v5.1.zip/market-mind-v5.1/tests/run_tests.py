#!/usr/bin/env python3
"""Запуск selftest всех модулей + интеграционная проверка экосистемы v5.0.
Код возврата 0 = все тесты прошли."""
import importlib,os,sys,traceback
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","scripts"))
mods=["mm_schema","mm_config","mm_data","mm_klines","mm_live","mm_regime","mm_analyst",
      "mm_council","mm_core","mm_risk","mm_journal","mm_feedback","mm_backtest","mm_alerts"]
fail=0
for m in mods:
    try: importlib.import_module(m).selftest()
    except Exception:
        fail+=1;print(m+": FAIL");traceback.print_exc()
def integration_conflict():
    """Сквозной сценарий: TA говорит LONG, Order Flow показывает давление продавцов,
    sentiment нейтрален. Система обязана зафиксировать конфликт, пересмотреть, в итоге NO TRADE,
    и Risk Gate обязан заблокировать план."""
    import mm_council,mm_risk
    up=[[i,100+i*0.1,100.5+i*0.1,99.5+i*0.1,100+i*0.1,1] for i in range(210)]
    up[-1]=[209,120.9,122.5,120.8,122.0,1];up[-2]=[208,120.8,121.0,119.0,120.9,1]
    war={"parts":{"tape":{"ok":True,"cvd":-6.0,"delta_pct":-5.0,"price_change_pct":-0.5,"divergence":False,"n":500,"age_sec":2.0},
                  "book":{"ok":False},"deriv":{"ok":True,"funding_pct":0.01,"oi":68000.0},
                  "fng":{"ok":True,"value":50,"delta3":0,"delta7":0,"classification":"Neutral"},
                  "lsr":{"ok":True,"ratio":1.0,"long_pct":50.0,"short_pct":50.0}}}
    d=mm_council.resolve(war,up,regime="trend_up")
    assert d["status"]=="NO_TRADE" and d["conflicts"],(d["status"],d["note"])
    plan={"id":"I1","pair":"BTCUSDT","side":"long","entry":73700,"stop":73110.4,"tp1":75321.4,"p":0.55,"lev":3,"risk_usd":1.5}
    r=mm_risk.check([plan],today="2026-01-01",decision=d)["results"][0]
    assert r["verdict"]=="BLOCK" and any(x.startswith("council:") for x in r["reasons"]),r
def integration_agree():
    """Согласованный сценарий: TA+Flow LONG, sentiment нейтрален -> AGREE -> PASS."""
    import mm_council,mm_risk
    up=[[i,100+i*0.1,100.5+i*0.1,99.5+i*0.1,100+i*0.1,1] for i in range(210)]
    up[-1]=[209,120.9,122.5,120.8,122.0,1];up[-2]=[208,120.8,121.0,119.0,120.9,1]
    agree={"parts":{"tape":{"ok":True,"cvd":5.0,"delta_pct":4.0,"price_change_pct":0.4,"divergence":False,"n":500,"age_sec":2.0},
                   "book":{"ok":True,"imbalance_pct":10.0},"deriv":{"ok":True,"funding_pct":0.01,"oi":68000.0},
                   "fng":{"ok":True,"value":50,"delta3":0,"delta7":0,"classification":"Neutral"},
                   "lsr":{"ok":True,"ratio":1.0,"long_pct":50.0,"short_pct":50.0}}}
    d2=mm_council.resolve(agree,up,regime="trend_up")
    assert d2["status"]=="AGREE" and d2["side"]=="long",d2["status"]
    plan={"id":"I1","pair":"BTCUSDT","side":"long","entry":73700,"stop":73110.4,"tp1":75321.4,"p":0.55,"lev":3,"risk_usd":1.5}
    r2=mm_risk.check([dict(plan,p=d2["p"])],today="2026-01-01",decision=d2,data_grade="A")["results"][0]
    assert r2["verdict"]=="PASS",r2["reasons"]
def integration_halt():
    """HALT: обязательный модуль (sentiment) INSUFFICIENT -> анализ остановлен."""
    import mm_council
    up=[[i,100+i*0.1,100.5+i*0.1,99.5+i*0.1,100+i*0.1,1] for i in range(210)]
    up[-1]=[209,120.9,122.5,120.8,122.0,1]
    snap={"parts":{"tape":{"ok":True,"cvd":5.0,"delta_pct":4.0,"price_change_pct":0.4,"divergence":False,"n":500,"age_sec":2.0},
                   "deriv":{"ok":True,"funding_pct":0.01,"oi":68000.0},
                   "fng":{"ok":False},"lsr":{"ok":False}}}
    d=mm_council.resolve(snap,up,regime="trend_up")
    assert d["status"]=="HALT",(d["status"],d["note"])
def integration_regime_prior():
    """Regime-приор: в trend_up приор ta выше, чем в range. Решение меняет p."""
    import mm_council
    up=[[i,100+i*0.1,100.5+i*0.1,99.5+i*0.1,100+i*0.1,1] for i in range(210)]
    up[-1]=[209,120.9,122.5,120.8,122.0,1];up[-2]=[208,120.8,121.0,119.0,120.9,1]
    snap={"parts":{"tape":{"ok":True,"cvd":5.0,"delta_pct":4.0,"price_change_pct":0.4,"divergence":False,"n":500,"age_sec":2.0},
                   "book":{"ok":True,"imbalance_pct":10.0},"deriv":{"ok":True,"funding_pct":0.01,"oi":68000.0},
                   "fng":{"ok":True,"value":50,"delta3":0,"delta7":0,"classification":"Neutral"},
                   "lsr":{"ok":True,"ratio":1.0,"long_pct":50.0,"short_pct":50.0}}}
    d_trend=mm_council.resolve(snap,up,regime="trend_up")
    d_range=mm_council.resolve(snap,up,regime="range")
    assert d_trend["status"]=="AGREE" and d_range["status"]=="AGREE",(d_trend["status"],d_range["status"])
    # ta голосует long в обоих; p_agg зависит от приоров: в trend_up выше -> p больше
    assert d_trend["p"]>d_range["p"],(d_trend["p"],d_range["p"])
def integration_sentiment_contradicts():
    """Sentiment корректирует сторону в range: Extreme Greed + LSR>1.4 -> short (контр-тренд)."""
    import mm_council
    flat=[[i,100,100.5,99.5,100,1] for i in range(220)]  # range по klines
    snap={"parts":{"tape":{"ok":True,"cvd":0.2,"delta_pct":0.5,"price_change_pct":0.1,"divergence":False,"n":500,"age_sec":2.0},
                   "book":{"ok":False},"deriv":{"ok":True,"funding_pct":0.01,"oi":68000.0},
                   "fng":{"ok":True,"value":82,"delta3":10,"delta7":15,"classification":"Extreme Greed"},
                   "lsr":{"ok":True,"ratio":1.6,"long_pct":61.5,"short_pct":38.5}}}
    d=mm_council.resolve(snap,flat,regime="range")
    assert d["status"]=="AGREE" and d["side"]=="short",(d["status"],d["note"])
def integration_feedback_loop():
    """Контур обратной связи: 25 compliant-сделок -> p_hat считается -> council его подхватывает."""
    import tempfile,mm_journal,mm_feedback,mm_council
    up=[[i,100+i*0.1,100.5+i*0.1,99.5+i*0.1,100+i*0.1,1] for i in range(210)]
    up[-1]=[209,120.9,122.5,120.8,122.0,1]
    snap={"parts":{"tape":{"ok":True,"cvd":5.0,"delta_pct":4.0,"price_change_pct":0.4,"divergence":False,"n":500,"age_sec":2.0},
                   "book":{"ok":True,"imbalance_pct":10.0},"deriv":{"ok":True,"funding_pct":0.01,"oi":68000.0},
                   "fng":{"ok":True,"value":50,"delta3":0,"delta7":0,"classification":"Neutral"},
                   "lsr":{"ok":True,"ratio":1.0,"long_pct":50.0,"short_pct":50.0}}}
    old=(mm_journal.BASE,mm_journal.J)
    with tempfile.TemporaryDirectory() as td:
        mm_journal.BASE,mm_journal.J=td,os.path.join(td,"j.csv")
        # пустой журнал: p_hat=None
        ph,_=mm_feedback.p_hat(min_n=20)
        assert ph is None
        d0=mm_council.resolve(snap,up,regime="trend_up")
        assert d0["p_hat_from_feedback"] is None
        # 25 сделок (10 win, 15 loss) -> p_hat~0.4
        for i in range(10):
            mm_journal.pre({"id":"W%d"%i,"module":"S","p":0.6,"risk_usd":1.0,"entry":100,"stop":99,"side":"long","regime":"trend_up"})
            mm_journal.post({"id":"W%d"%i,"exit":102,"result_usd":1.0,"scenario_hit":1,"compliant":1})
        for i in range(15):
            mm_journal.pre({"id":"L%d"%i,"module":"S","p":0.6,"risk_usd":1.0,"entry":100,"stop":99,"side":"long","regime":"trend_up"})
            mm_journal.post({"id":"L%d"%i,"exit":99,"result_usd":-1.0,"scenario_hit":0,"compliant":1})
        ph,info=mm_feedback.p_hat(min_n=20)
        assert ph is not None and abs(ph-0.4)<1e-6,(ph,info)
        # council теперь подхватывает p_hat (use_feedback_prior=True по умолчанию)
        d1=mm_council.resolve(snap,up,regime="trend_up")
        assert d1["p_hat_from_feedback"] is not None,d1
        # p чуть ниже d0 (т.к. p_hat=0.4 < базы 0.60 -> корректировка вниз)
        assert d1["p"]<=d0["p"],(d0["p"],d1["p"])
    mm_journal.BASE,mm_journal.J=old
def integration_klines_fallback():
    """klines: REST падает -> fallback на второй источник -> на CSV."""
    import mm_klines
    import unittest.mock as mock
    fake_csv=[(i,100,101,99,100,1) for i in range(220)]
    with mock.patch("mm_klines.from_binance",return_value=None),\
         mock.patch("mm_klines.from_bybit",return_value=fake_csv):
        r,src,q=mm_klines.fetch("BTCUSDT",prefer="binance")
        assert src=="bybit" and q["ok"] and len(r)==220
def integration_manifest():
    """ENACLEE.json: манифест валиден, граф целостен, все node_types имеют fn."""
    import json
    p=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","ENACLEE.json")
    with open(p,encoding="utf-8") as f: m=json.load(f)
    assert m["enaclee"]=="1.0" and m["skill"]=="market-mind" and m["version"]=="5.1"
    assert len(m["agents"])==8 and {a["id"] for a in m["agents"]}>= {"ta","flow","deriv","sentiment","council"}
    for path in m["validation"]["required_paths"]:
        assert os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)),"..",path)),path
    g=m["nodes"]["initial_graph"]
    ids={n["id"] for n in g["nodes"]}
    assert all(e["from"] in ids and e["to"] in ids for e in g["edges"])
    types={t["id"] for t in m["nodes"]["node_types"]}
    assert all(n["type"] in types for n in g["nodes"])
    assert all("fn" in t for t in m["nodes"]["node_types"])
    # URL-шаблоны API содержат плейсхолдеры
    assert "{symbol}" in m["api"]["klines"]["bybit"] and "{interval}" in m["api"]["klines"]["bybit"]
    print("manifest: OK")
def integration():
    for fn in (integration_conflict,integration_agree,integration_halt,
               integration_regime_prior,integration_sentiment_contradicts,
               integration_feedback_loop,integration_klines_fallback,integration_manifest):
        fn()
    print("integration: OK")
try: integration()
except Exception:
    fail+=1;print("integration: FAIL");traceback.print_exc()
print("RESULT:","ALL PASS" if fail==0 else str(fail)+" FAIL")
sys.exit(1 if fail else 0)
