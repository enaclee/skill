---
name: market-mind
description: >-
  Аналитик крипто-рынка (spot и фьючерсы Binance USDT-M / Bybit v5) с экосистемной архитектурой
  и обратной связью. Цепочка А→Б: Рынок -> Ingestion (klines/лента/книга/funding/OI/LSR/F&G)
  -> Regime (trend_up/trend_down/range/volatile — «психология фазы») -> 4 НЕЗАВИСИМЫХ
  аналитика (ta/flow/deriv/sentiment) -> Council (cross-validation + regime-приоры +
  feedback p_hat из журнала) -> Risk Gate (право вето: council NO_TRADE/HALT, grade D,
  сторона ≠ совету — всё BLOCK) -> Output. Адаптируется под психологию рынка: в trend
  доверяет ta, в range — deriv (контр-тренд funding), в volatile — прижимает приоры к
  нейтрали. sentiment (толпа: F&G + long/short ratio) — отдельный голос; экстремум толпы
  даёт контр-трендовую сторону. Журнал замыкает контур: после 20 compliant-сделок p_hat
  корректирует приоры. Перцентиль funding за 30д, live klines REST, настраиваемые комиссии.
  Ничего не торгует: ордера не открывает/не закрывает/не отправляет.
  Используй, когда пользователь говорит «что на рынке», «проверь сделку», «можно ли
  входить», «разбери BTC/ETH», «журнал», «бэктест», «алерт», «funding», «тренд/флэт»,
  «толпа лонгует/шортует», «режим рынка», «спот/фьючерс».
argument-hint: "[пара или задача, например BTCUSDT]"
---

# market-mind v5.1

Аналитическая экосистема с обратной связью, а не набор индикаторов. Реальные ордера
не открывает, не закрывает и не отправляет. Любое решение о сделке остаётся за
пользователем. `${CLAUDE_SKILL_DIR}` — папка, где лежит этот SKILL.md.

## Архитектура (цепочка А→Б)

```
Рынок → Ingestion → Regime → 4 Аналитика → Council (cross-validation + feedback)
                     |                          |
                     v                          v
              «психология фазы»        Decision (AGREE/NO_TRADE/HALT)
                     ^                          |
                     |                          v
                     +------- Journal <--- Risk Gate (вето)
                              |                |
                              v                v
                          Feedback p_hat     Output (audit)
                              |
                              +-> обратно в Council (контур замкнут)
```

- **Ingestion** (`mm_live`, `mm_klines`, `mm_data`):
  - `mm_live --snapshot`: лента/CVD/дельта, книга (спуфабельно — вторичный признак),
    funding, OI, **LSR** (long/short account ratio — толпа), **F&G** с **дельтами 3/7д**;
    грейд A/C/D. Binance WAF часто блокирует серию запросов → fallback на Bybit v5
    (publicTrade/recent-trade для tape, tickers для funding+OI). `--budget` сек.
  - `mm_klines fetch`: REST klines Binance или Bybit (публичные, без ключей),
    fallback на CSV. В v4 свечи можно было подать только вручную из CSV.
- **Regime** (`mm_regime`): классифицирует фазу по свечному ряду:
  - `trend_up`/`trend_down`: цена снаружи MA200, трендовая сила (DI-proxy) заметна;
  - `range`: цена внутри полосы, низкая трендовая сила — контр-тренд доминирует;
  - `volatile`: ATR% ≥ 3% или BB-ширина ≥ 8% — приоры прижимаются к нейтрали;
  - `unknown`: данных мало.
  Это «психология фазы»: в тренде ta решает, в range deriv решает, в volatile все осторожны.
- **Analysis** (`mm_analyst`): 4 НЕЗАВИСИМЫХ модуля, каждый со своим **regime-приором**:
  - `ta` — тренд/пробой MA28/MA200 с подтверждением импульсом (нужен klines);
  - `flow` — лента/CVD/дельта/книга (книга — вторичный, спуфабельный);
  - `deriv` — funding/OI: **перцентиль funding за 30д** (если есть история), иначе
    порог ±0.05%; экстремум → контр-трендовое давление, нейтраль → flat;
  - `sentiment` — **толпа**: F&G (Extreme Greed ≥75 → short, Extreme Fear ≤25 → long),
    LSR (≥1.4 толпа лонгует → short, ≤0.7 толпа шортует → long), F&G дельта 3д ускоряет
    разворот (|Δ| ≥ 15 пунктов). Контр-трендовая логика — это и есть психология рынка.
  Каждый выдаёт `side ∈ {long, short, flat}`, `p`, `confidence`, `evidence[]`, `invalidate[]`.
  `ok=false` → INSUFFICIENT (HALT), оценок «на глаз» нет.
- **Cross-Validation** (`mm_council`): совет проверяет выводы аналитиков друг против друга:
  - конфликт long/short при обеих `conf ≥ conflict_min_conf` (0.6) → REVISIT слабейшего
    (conservative: conf×0.7, p к нейтрали); после пересмотра остаточный конфликт → **NO TRADE (CONFLICT)**;
  - мягкий конфликт (`< 0.6`) — слабая сторона отбрасывается с пометкой в audit;
  - все flat / нет голосов — **NO TRADE** («нет перевеса»);
  - обязательный модуль INSUFFICIENT — **HALT** (право остановить анализ).
  - **regime-приоры** влияют на p_agg: в trend_up p выше, в range ниже;
  - **feedback p_hat**: если в журнале ≥ 20 compliant-сделок, p_hat (взвешенный observed
    hit-rate) аккуратно корректирует приоры аналитиков (±0.05). Контур замкнут.
- **Risk Gate** (`mm_risk`): право заблокировать любое решение. Вето: council NO_TRADE/HALT,
  сторона плана ≠ стороне совета, грейд D, при грейде C нужен p ≥ 0.6. Экономика: 4 фильтра
  (target ≥ 4×C, RR ≥ 2, E > 0, C ≤ 25% стопа), лот, маржа, буфер ликвидации, дневные лимиты.
  **Комиссии настраиваются** в `data/config.json` (Bybit VIP0 / Binance tier0 по умолчанию).
  BLOCK окончателен: модуль не правит план и не ослабляет лимиты.
- **Output**: вердикт совет + ворота + reasoning (audit trail). NO TRADE — полноценный исход.
- **Journal + Feedback** (`mm_journal`, `mm_feedback`): только после PASS — `mm_journal pre`
  с council-полями (status/side/note) и `regime`. После выхода — `mm_journal post` с
  `exit/result_usd/scenario_hit/compliant/regime`. `mm_feedback report` показывает p_hat и
  edge по режимам: где стратегия работает, где переоценивает. Это и есть «нейронная связь».

## Команды

```bash
python3 "${CLAUDE_SKILL_DIR}/tests/run_tests.py"                              # все selftest + 7 интеграций, ждём ALL PASS
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_live.py" --snapshot [--symbol ETHUSDT] [--budget 45]   # лента/CVD/книга/funding/OI/LSR/F&G (грейд)
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_klines.py" --symbol BTCUSDT --interval 1h --limit 300  # REST klines Binance/Bybit, fallback --csv
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_data.py" --selftest                  # качество рядов, честная свежесть
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_regime.py" --klines data/klines.csv   # классификация фазы рынка
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_analyst.py" --snap snap.json --klines klines.csv --regime trend_up   # вердикты 4 модулей
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_council.py" --decide --snap snap.json --klines k.csv [--regime trend_up] [--json]
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_core.py" --price 73700 --stop 0.8 --target 2.2 --risk 1.5 --lev 3
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_risk.py" check '<план JSON>' [--decision decision.json] [--grade A|C|D]
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_journal.py" pre '<план>' --require-gate
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_journal.py" post '<итог>'
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_journal.py" stats                     # edge + edge_by_regime + calibration + Brier
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_feedback.py" --report                 # p_hat + edge по режимам (контур обратной связи)
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_backtest.py" --csv data/klines.csv [--council] [--regime-aware]
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_backtest.py" --demo 6000 --windows 4  # синтетика, помечается SYNTHETIC
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_alerts.py" add --symbol BTCUSDT --stop 73000 --side long
python3 "${CLAUDE_SKILL_DIR}/scripts/mm_alerts.py" check
```

План для `mm_risk` и `mm_journal pre` — один и тот же JSON:
`{"id","module","pair","side":"long|short","entry","stop","tp1","p","lev","risk_usd"}`
(необязательно: `funding_pct`, `n_funding`, `tp2`, `regime`, `horizon_h`,
`council_status`, `council_side`, `council_note`, `p_hat` — фиксация решения совета).

## Шаги (цепочка от А до Б)

1. **Ingestion.** Живой вопрос: `mm_live --snapshot` (лента/CVD/книга/funding/OI/LSR/F&G
   с дельтами 3/7д). Если grade D — останавливаемся. Параллельно `mm_klines fetch` (REST).
   Время получения данных называть всегда: снимок дискретен, агент не смотрит рынок 24/7.
2. **Regime.** `mm_regime --klines klines.csv` — классифицировать фазу. Если `unknown` —
   приоры берутся из `unknown` (близко к нейтрали). regime передаётся во все аналитики.
3. **Analysis + Cross-Validation.** `mm_council --decide --snap ... --klines ... --regime ...`.
   NO_TRADE/HALT — передать пользователю причину и audit, не пытаться «дожать» сценарий.
   При AGREE взять `side`, `p`, `confidence`, `regime`, `p_hat_from_feedback`.
4. **Экономика.** `mm_core`: издержки по сторонам (с настраиваемыми комиссиями), чистый RR,
   лот, буфер ликвидации. Эталон: стоп 0.8%, цель 2.2%, C=0.176% проходит; стоп 0.7%,
   цель 2.0% отклоняется по лимиту издержек (регрессия в selftest).
5. **Risk Gate.** `mm_risk check --decision <совет> --grade <грейд>`: пропускает только
   согласованный сценарий. Причина блока по каждому пункту простыми словами; лимиты
   самому не менять, план «под проход» не править. BLOCK окончателен.
6. **Журнал.** Только после PASS: `mm_journal pre --require-gate`. Отпечаток плана
   (нормализованный, lev по умолчанию учтён) должен совпадать; правка плана = новая
   проверка. В записи фиксируются council-поля и regime: вход при NO TRADE виден в
   статистике как нарушение.
7. **Итог.** `mm_journal post` с `exit`, `result_usd`, `scenario_hit` (0/1), `compliant`
   (0/1), `regime`. Эдж и дисциплина считаются раздельно.
8. **Наблюдение.** `mm_alerts`: уровни, стопы с учётом стороны (`--side long/short` для
   stop/target), % за 24ч, funding. Алерт — факт о цене, не сигнал.
9. **Обратная связь.** После ≥ 20 compliant-сделок `mm_feedback --report` показывает
   p_hat и edge по режимам. Если p_hat < базы приор модуля — council слегка опустит
   его приоры в следующем анализе. Контур замкнут.

## Правила

- Рабочая вероятность p = regime-приор + 0.025×сила сигнала; если в журнале ≥ 20
  compliant-сделок и `use_feedback_prior=True` — приор дополнительно корректируется
  через p_hat (±0.05). Пока n < 20 — LOW CONFIDENCE, вердикта об эдже нет.
- Метрика заявляется только если за ней есть функция (контракт в `SKILL_PATCH.md`).
  Нет данных — INSUFFICIENT, не оценка «на глаз».
- Ликвидации Binance — только WebSocket; в `mm_live` помечены WS-only, резерв — Coinglass.
- Дисбаланс книги спуфится: вторичный признак, подтверждать лентой и CVD.
- Бэктест на синтетике (`--demo`) эдж не доказывает. Реальные выводы — по `--csv` и
  OOS-окнам. Режим `--council` показывает цену NO TRADE: пропущенные сигналы считаются.
  `--regime-aware` адаптирует atr_mult по фазе (volatile — шире стоп).
- Live-запросы имеют общий бюджет времени (`--budget`): при недоступных источниках
  модули возвращают структуру с ошибками и грейд D, а не висят.
- Binance WAF (HTTP 418) часто блокирует серию запросов без API-ключа. `mm_live`
  использует jitter 0.3с между эндпоинтами и fallback на Bybit v5 (publicTrade для tape,
  tickers для funding+OI). Грейд D честно отражает «нет данных», не «рынок спокоен».
- Платные API не подключать без проверки стоимости и лимитов. API-ключи не требуются:
  все источники публичные (Binance USDT-M REST, Bybit v5 public, alternative.me F&G).
- Конфликт модулей разрешается только через REVISIT; если после него противоречие
  осталось — NO TRADE. Система не выдаёт сигнал, противоречащий собственному анализу.
- sentiment-голос (толпа) не veto, а голос: экстремум F&G или LSR даёт сторону, но
  council может отбросить её при мягком конфликте. Это и есть психология рынка в деле.

## Чего не делает

Не отправляет и не отменяет ордера, не подключает биржевые ключи, не обещает результат,
не подменяет решение пользователя. Это аналитика и учёт, не инвестиционная рекомендация.

## Реализовано в v5.0 (раньше было «не реализовано» в v4)

- Перцентиль funding за 30д (`deriv_analyze(funding_history=...)` — 95/5 перцентиль);
- Дельта F&G 3/7д (`mm_live.fng_calc` — главное для психологии толпы);
- Long/Short account ratio (`mm_live.lsr_calc` + `mm_analyst.sentiment_analyze`);
- Классификатор режима рынка (`mm_regime.classify` — trend_up/down/range/volatile);
- Live klines REST (`mm_klines.from_binance/bybit` — без ручного CSV);
- Контур обратной связи p_hat (`mm_feedback.p_hat/regime_p_hat` + council adjust);
- Настраиваемые комиссии (`mm_config.fees` + `data/config.json` + env MM5_*);
- 4-й аналитик sentiment (толпа) как обязательный голос (HALT при INSUFFICIENT);
- edge_by_regime в журнальной статистике (где стратегия работает по фазам);
- Binance WAF fallback на Bybit v5 (publicTrade для tape, tickers для funding+OI).

## Пока не реализовано (не заявлять как метрики)

Rolling beta и корреляции BTC/altcoin, объёмные кластеры/POC, отдельная функция `p_hat`
как самостоятельный API (сейчас доступна через `mm_feedback.p_hat()`), генератор
отчёта из 20 пунктов ТЗ. Ставить INSUFFICIENT или считать вручную с явной пометкой.

## ENACLEE WEB (v5.1)

Скилл исполняется не только локально (Python CLI), но и в браузере через оболочку
`enaclee.html` (проект enaclee.skill). Манифест `ENACLEE.json` в корне скилла — контракт
между сайтом и скиллом:

- `agents` — 8 агентов чата (РЕЖИМ/ТРЕНД/ПОТОК/ДЕРИВ/ТОЛПА/СОВЕТ/РИСК/ОБУЧЕНИЕ);
- `api` — CORS-доступные публичные источники (Bybit v5, Binance fapi, alternative.me F&G);
- `nodes` — карта логики для редактора «Разум»: типы нод и стартовый граф;
- `validation` — что сайт проверяет при загрузке zip (структура, обязательные файлы);
- `storage` — схема IndexedDB (journal/hypotheses/results/config) с экспортом в CSV.

Логика движка в браузере — это порт `mm_regime / mm_analyst / mm_council / mm_core` на JS
с сохранением контрактов `mm_schema` (те же поля и статусы). Python-скрипты остаются
эталоном: браузерный вердикт должен совпадать с `mm_council.resolve()` на тех же данных
(проверяется тестом parity в tests/run_tests.py — `parity`-модуль сравнивает решения).
Сайт не торгует и не хранит ключи бирж: поля «входа» в Офисе — только для чтения
баланса через публичные эндпоинты, если пользователь их заполнит.
