# Живые источники v5.0: где видно, как торгуют люди

Визуализация в реальном времени:
- aggr.trade — лента сделок, CVD, ликвидации по биржам, бесплатно
- Bookmap — тепловая карта книги заявок, поглощение, платно (есть демо)
- TensorCharts / Exocharts — footprint, дельта, профиль объёма, freemium
- Coinglass / Coinank / Coinalyze — ликвидации, OI, funding, long/short, freemium
- TradingView — график и алерты, бесплатно
- Hyblock — карты ликвидаций, платно

Публичные потоки бирж (WebSocket):
- Binance USDT-M: wss://fstream.binance.com/ws/btcusdt@aggTrade
  книга: btcusdt@depth20@100ms ; ликвидации: !forceOrder@arr ; mark/funding: btcusdt@markPrice@1s
- Bybit v5: wss://stream.bybit.com/v5/public/linear
  топики: publicTrade.BTCUSDT, orderbook.50.BTCUSDT, liquidation.BTCUSDT, tickers.BTCUSDT

REST, реально используется в коде (публичные, БЕЗ API-ключей):
- mm_klines.py:
  - Binance USDT-M: /fapi/v1/klines (interval=1h, limit=300) — основной источник свечей
  - Bybit v5: /v5/market/kline?category=linear&interval=60 — fallback
- mm_live.py (снимок рынка):
  - Binance: /fapi/v1/aggTrades, /depth, /premiumIndex, /openInterest,
    /futures/data/globalLongShortAccountRatio (LSR — толпа, НОВОЕ в v5)
  - Bybit v5 fallback (когда Binance WAF даёт 418):
    /v5/market/recent-trade?category=linear (tape), /v5/market/tickers?category=linear (funding+OI)
  - F&G: api.alternative.me/fng/?limit=7 — Fear&Greed с историей 7д для дельт 3/7д
- mm_alerts.py (Binance USDT-M): /fapi/v1/ticker/24hr и /premiumIndex
- mm_data.py: проверка качества источников через те же эндпоинты

REST, заявленное в v4 «не реализовано» — теперь РЕАЛИЗОВАНО в v5:
- fapi.binance.com/fapi/v1/klines (mm_klines.from_binance) — live свечи для ta/бэктеста
- api.bybit.com/v5/market/kline, /funding/history (mm_klines.from_bybit; deriv_history планируемый)
- fapi.binance.com/futures/data/globalLongShortAccountRatio (mm_live.lsr_calc) — толпа
- api.alternative.me/fng/?limit=7 (mm_live.fng_calc) — F&G с дельтами 3/7д

Ограничения, которые нельзя игнорировать:
1. Ликвидации Binance в реальном времени только через WS; REST allForceOrders закрыт.
   В mm_live они помечены WS-only, резерв — Coinglass.
2. Дисбаланс книги спуфится: вторичный признак, подтверждать лентой и CVD.
3. Агент не смотрит рынок 24/7: снапшоты дискретны, время получения фиксируется.
4. Платные API не подключать без проверки стоимости и лимитов. API-ключи НЕ требуются:
   все источники публичные (Binance USDT-M REST, Bybit v5 public, alternative.me F&G).
5. v5.0: живые опросы имеют общий бюджет времени (--budget). Если источники недоступны
   (блокировка сети, таймауты), модули возвращают структуру с grade D и списком ошибок,
   а не зависают; анализ останавливается (HALT/INSUFFICIENT), сделка невозможна.
   Проверка доступности конкретной сети — обязанность среды запуска: грейд D честно
   отражает «нет данных», он не должен трактоваться как «рынок спокоен».
6. v5.0: Binance WAF (HTTP 418 "I'm a teapot") часто блокирует серию быстрых запросов
   без API-ключа с одного IP. mm_live использует:
   - jitter 0.3с между эндпоинтами (снижает риск блока);
   - fallback на Bybit v5 (publicTrade для tape, tickers для funding+OI) при провале Binance.
   Если оба провалились — grade D, анализ остановлен. Это особенность Binance WAF, не баг скилла.

Ориентир актуальности (проверено при сборке v5.0, 2026-11-12, live snapshot grade=A):
- Binance BTCUSDT aggTrades: CVD по 500 сделкам; depth20: imbalans; premiumIndex: funding
- Bybit BTCUSDT v5 tickers: last, fundingRate, openInterest (fallback)
- Binance LSR (BTCUSDT 1h): ratio ~2.86 — толпа лонгует
- Fear & Greed: 28 (Fear), delta3=-4, delta7=0 (страх нарастает за 3д)
Значения дискретны и быстро устаревают — всегда брать свежий снимок.

Что НЕ требует API-ключей (важно для пользователя):
- Binance USDT-M public REST: klines, aggTrades, depth, premiumIndex, openInterest,
  globalLongShortAccountRatio, ticker/24hr — все публичные, без ключей.
- Bybit v5 public REST: market/kline, market/recent-trade, market/tickers — публичные.
- alternative.me/fng — публичный.
Скилл НЕ запрашивает и НЕ хранит API-ключи. Если пользователь хочет приватные эндпоинты
(кошелёк, ордера, торговля) — это вне области скилла; для этого нужны отдельные ключи
с правами, которые пользователь хранит сам.
