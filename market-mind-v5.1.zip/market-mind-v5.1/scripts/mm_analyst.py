#!/usr/bin/env python3
"""Аналитики v5.0: ta / flow / deriv / sentiment. Каждый НЕЗАВИСИМО выдаёт
side ∈ {long, short, flat}, p, confidence, evidence[], invalidate[].

Главные отличия от v4:
- 4 модуля вместо 3: добавлен sentiment (толпа: F&G + LSR) — это и есть «психология рынка».
- Приор p Prior берётся из mm_config.prior_for(module, regime) — зависит от фазы рынка.
  В v4 был плоский 0.55. Здесь trend_up повышает ta, range повышает deriv, volatile всё давит.
- conservative-пересмотр (REVISIT) сохранён: confidence×0.7, p к нейтрали.
- ok=False -> INSUFFICIENT, оценок «на глаз» нет (HALT).
"""
import mm_config,mm_regime,mm_schema
SIDES=mm_schema.SIDES
def _out(module):
    return {"module":module,"ok":False,"side":"flat","p":0.5,"confidence":0.0,
            "evidence":[],"invalidate":[],"note":""}
def _clamp(x,a,b): return max(a,min(b,x))
def _conserv(s):
    s=dict(s);s["confidence"]=round(s["confidence"]*0.7,4);s["p"]=round(0.5+(s["p"]-0.5)*0.7,4)
    s["note"]=(s["note"]+" " if s["note"] else "")+"[conservative revisit]"
    return s
# ---------- TA: тренд/пробой MA28/MA200 с подтверждением импульсом ----------
def ta_analyze(klines=None,conservative=False,regime=None,cfg=None):
    c=cfg or mm_config.load()
    out=_out("ta")
    rows=[r for r in (klines or []) if isinstance(r,(list,tuple)) and len(r)>=5 and all(x>0 for x in (r[1],r[2],r[3],r[4]))]
    if len(rows)<c["min_klines"]:
        out["note"]="INSUFFICIENT: для ta нужно >=%d свечей; получено %d"%(c["min_klines"],len(rows))
        return out
    closes=[r[4] for r in rows];cx=closes[-1];prev=closes[-2]
    fast=sum(closes[-28:])/28;slow=sum(closes[-200:])/200
    trs=[max(rows[j][2]-rows[j][3],abs(rows[j][2]-closes[j-1]),abs(rows[j][3]-closes[j-1])) for j in range(len(rows)-14,len(rows))]
    atr=sum(trs)/14
    prev_low=rows[-2][3];prev_high=rows[-2][2]
    long_sig=cx>slow and prev_low<=fast and cx>prev and cx>fast
    short_sig=cx<slow and prev_high>=fast and cx<prev and cx<fast
    if not (long_sig or short_sig):
        out.update(ok=True,note="нет сигнала: цена вне условий пробоя MA28 при тренде по MA200")
        out["evidence"]=[f"close={cx:.1f} vs MA28={fast:.1f}, MA200={slow:.1f}"]
        return out
    side="long" if long_sig else "short"
    dist=abs(cx-slow)/atr if atr>0 else 0.0
    prior=mm_config.prior_for("ta",regime,c)  # приор зависит от режима
    conf=_clamp(0.55+0.05*min(dist,2.0),0.55,0.75)
    p=round(_clamp(prior+0.025*min(dist,2.0),0.5,0.8),4)
    out.update(ok=True,side=side,p=p,confidence=round(conf,4))
    out["evidence"]=[f"тренд: close {cx:.1f} {'выше' if side=='long' else 'ниже'} MA200 ({slow:.1f}) на {dist:.2f} ATR",
                     f"пробой MA28={fast:.1f}: close {'>' if side=='long' else '<'} MA28",
                     f"импульс: close {prev:.1f} -> {cx:.1f}; prior={prior:.2f} (regime={regime or 'unknown'})"]
    out["invalidate"]=[f"close возвращается {'ниже' if side=='long' else 'выше'} MA28 ({fast:.1f})",
                       f"ATR14={atr:.4f}: волатильность <0.5x — сигнал стареет"]
    return _conserv(out) if conservative else out
# ---------- FLOW: лента/CVD/дельта/книга (микроструктура) ----------
def flow_analyze(snap=None,conservative=False,regime=None,cfg=None):
    c=cfg or mm_config.load()
    out=_out("flow")
    tape=(snap or {}).get("parts",{}).get("tape",{})
    if not tape.get("ok"): out["note"]="INSUFFICIENT: нет ленты сделок (snap.parts.tape.ok=false)";return out
    cvd=tape.get("cvd",0.0);dp=tape.get("delta_pct",0.0);pc=tape.get("price_change_pct",0.0);div=tape.get("divergence",False);n=tape.get("n",0)
    book=(snap or {}).get("parts",{}).get("book",{});imb=book.get("imbalance_pct") if book.get("ok") else None
    side="flat";conf=0.0
    # в volatile порог перевеса выше — меньше ложных сигналов
    thr=2.0 if regime!="volatile" else 3.0
    if cvd>0 and dp>=thr and pc>0 and not div: side="long"
    elif cvd<0 and dp<=-thr and pc<0 and not div: side="short"
    if side=="flat":
        out.update(ok=True,note="нет перевеса агрессоров"+("; дивергенция цена/CVD" if div else ""))
        out["evidence"]=[f"CVD={cvd} ({dp:+.2f}% от объёма ленты), цена {pc:+.3f}%"+(", дивергенция" if div else "")]
        if div: out["invalidate"]=["дивергенция: поток и цена разошлись — доверие к потоку ниже"]
        return _conserv(out) if conservative else out
    strength=min(abs(dp)/10.0,1.0)
    prior=mm_config.prior_for("flow",regime,c)
    conf=_clamp(0.55+0.25*strength,0.55,0.9)
    if div: conf=round(conf*0.7,4)
    p=round(_clamp(prior+0.05*strength,0.5,0.8),4)
    out.update(ok=True,side=side,p=p,confidence=round(conf,4))
    out["evidence"]=[f"CVD={cvd:+.4f}, дельта {dp:+.2f}% по {n} сделкам ленты",
                     f"цена {pc:+.3f}% за окно ленты, возраст ленты {tape.get('age_sec')}с"]
    if imb is not None and abs(imb)>=20.0:
        agree=(imb>0)==(side=="long")
        out["evidence"].append(f"книга: дисбаланс {imb:+.1f}% {'в сторону' if agree else 'ПРОТИВ'} сигнала (спуфабельно)")
        if not agree: out["confidence"]=round(out["confidence"]*0.85,4)
    if div: out["evidence"].append("дивергенция цена/CVD — сигнал ослаблен")
    out["invalidate"]=["CVD меняет знак на противоположный","дельта падает по модулю ниже 1%"]
    return _conserv(out) if conservative else out
# ---------- DERIV: funding/OI + ПЕРЦЕНТИЛЬ funding 30д ----------
def deriv_analyze(snap=None,conservative=False,regime=None,cfg=None,funding_history=None):
    """v5: funding сравнивается не с фиксированным 0.05 (как в v4), а с перцентилем
    за 30 дней — «экстремальность» определяется относительно самого рынка, а не порога.
    funding_history: список funding_pct за ~30 дней (старые -> новые). Если нет — fallback на порог."""
    c=cfg or mm_config.load()
    out=_out("deriv")
    d=(snap or {}).get("parts",{}).get("deriv",{})
    if not d.get("ok"): out["note"]="INSUFFICIENT: нет деривативных данных (funding/mark)";return out
    f=d.get("funding_pct",0.0);oi=d.get("oi")
    # перцентиль funding за историю, если есть
    pct_rank=None
    if funding_history and len(funding_history)>=10:
        sorted_h=sorted(funding_history)
        k=int((len(sorted_h)-1)*0.95)  # 95-й перцентиль для экстремума
        extreme_hi=sorted_h[k];extreme_lo=sorted_h[max(0,int((len(sorted_h)-1)*0.05))]
        # ранг текущего funding в истории
        below=sum(1 for x in funding_history if x<=f)
        pct_rank=round(below/len(funding_history)*100,1)
        ext_hi_ok=f>=extreme_hi;ext_lo_ok=f<=extreme_lo
        out["evidence"]=[f"funding={f:+.4f}% (персентиль {pct_rank} из 100 за 30д, окно={len(funding_history)})"]
    else:
        ext_hi_ok=f>=c["funding_extreme_pct"];ext_lo_ok=f<=-c["funding_extreme_pct"]
        out["evidence"]=[f"funding={f:+.4f}% (без истории: порог ±{c['funding_extreme_pct']}%)"]
    out["evidence"].append(f"OI={oi} BTC" if oi else "OI нет")
    side="flat";conf=0.0
    if ext_hi_ok: side,conf="short",0.6   # лонги перегреты и платят — контр-трендовое давление
    elif ext_lo_ok: side,conf="long",0.6  # шорты перегреты — потенциал сквиза вверх
    prior=mm_config.prior_for("deriv",regime,c)
    p=round(_clamp(prior if side!="flat" else 0.5,0.5,0.8),4)
    out.update(ok=True,side=side,p=p,confidence=round(conf,4))
    if side=="short": out["note"]="перегретый funding: экстремум давления лонгов — контр-тренд"
    elif side=="long": out["note"]="отрицательный funding: давление шоротов — потенциал сквиза вверх"
    else: out["note"]="funding нейтрален: режим не даёт стороны"
    if oi: out["invalidate"]=["funding возвращается в нейтральный диапазон"]
    return _conserv(out) if conservative else out
# ---------- SENTIMENT: толпа F&G + LSR (главное добавление v5) ----------
def sentiment_analyze(snap=None,conservative=False,regime=None,cfg=None):
    """Толпа = психология рынка. Контр-трендовая логика:
    - Extreme Greed (F&G>=75) или толпа лонгует (LSR>=1.4) -> short (контр-тренд);
    - Extreme Fear (F&G<=25) или толпа шортует (LSR<=0.7) -> long (контр-тренд);
    - F&G дельта 3/7д ускоряет разворот (резкий рост Greed -> перегрев).
    В тренде sentiment слабее (приор ниже), в range — сильнее (развороты часты)."""
    c=cfg or mm_config.load()
    out=_out("sentiment")
    parts=(snap or {}).get("parts",{})
    fng=parts.get("fng",{});lsr=parts.get("lsr",{})
    if not fng.get("ok") and not lsr.get("ok"):
        out["note"]="INSUFFICIENT: нет ни F&G, ни LSR";return out
    votes=[];ev=[]
    if fng.get("ok"):
        v=fng["value"];d3=fng.get("delta3",0);d7=fng.get("delta7",0)
        ev.append(f"F&G={v} ({fng.get('classification','')}), дельта 3д={d3:+d}, 7д={d7:+d}")
        if v>=c["fng_extreme_high"]: votes.append(("short",0.55));ev.append("Extreme Greed -> контр-тренд short")
        elif v<=c["fng_extreme_low"]: votes.append(("long",0.55));ev.append("Extreme Fear -> контр-тренд long")
        # ускорение: резкий рост Greed за 3д (>15 пунктов) усиливает short
        if d3>=15: votes.append(("short",0.6));ev.append("F&G рост +15 за 3д -> перегрев усиливается")
        elif d3<=-15: votes.append(("long",0.6));ev.append("F&G падение -15 за 3д -> паника усиливается")
    if lsr.get("ok"):
        r=lsr["ratio"];ev.append(f"LSR={r} (long {lsr.get('long_pct')}% / short {lsr.get('short_pct')}%)")
        if r>=c["lsr_extreme"]: votes.append(("short",0.55));ev.append("LSR>=%.1f -> толпа лонгует, контр-тренд short"%c["lsr_extreme"])
        elif r<=c["lsr_low"]: votes.append(("long",0.55));ev.append("LSR<=%.2f -> толпа шортует, контр-тренд long"%c["lsr_low"])
    if not votes:
        out.update(ok=True,note="толпа нейтральна: F&G и LSR в средних диапазонах")
        out["evidence"]=ev;return _conserv(out) if conservative else out
    # суммируем голоса по сторонам
    long_w=sum(w for s,w in votes if s=="long")
    short_w=sum(w for s,w in votes if s=="short")
    if long_w>short_w: side="long";w=long_w
    elif short_w>long_w: side="short";w=short_w
    else: side="flat";w=0
    if side=="flat":
        out.update(ok=True,note="голоса толпы уравновешены")
        out["evidence"]=ev;return _conserv(out) if conservative else out
    prior=mm_config.prior_for("sentiment",regime,c)
    p=round(_clamp(prior+0.02*w,0.5,0.72),4)
    conf=round(_clamp(0.55+0.05*w,0.55,0.7),4)
    out.update(ok=True,side=side,p=p,confidence=conf)
    out["evidence"]=ev
    out["invalidate"]=["F&G возвращается в 30..70","LSR входит в 0.7..1.4"]
    return _conserv(out) if conservative else out
# ---------- сборка ----------
def analyze_all(snap=None,klines=None,conservative=None,regime=None,cfg=None,funding_history=None):
    """conservative: None | множество имён модулей для пересмотра.
    regime: режим рынка (mm_regime.classify) — влияет на приоры.
    funding_history: для deriv (перцентиль 30д).
    Возвращает {module: verdict}."""
    cons=conservative or set()
    kw=dict(regime=regime,cfg=cfg)
    return {"ta":ta_analyze(klines,conservative="ta" in cons,**kw),
            "flow":flow_analyze(snap,conservative="flow" in cons,**kw),
            "deriv":deriv_analyze(snap,conservative="deriv" in cons,funding_history=funding_history,**kw),
            "sentiment":sentiment_analyze(snap,conservative="sentiment" in cons,**kw)}
def selftest():
    up=[[i,100+i*0.1,100.5+i*0.1,99.5+i*0.1,100+i*0.1,1] for i in range(210)]
    up[-1]=[209,120.9,122.5,120.8,122.0,1];up[-2]=[208,120.8,121.0,119.0,120.9,1]
    # ta: тренд вверх -> long
    a=ta_analyze(up,regime="trend_up")
    assert a["ok"] and a["side"]=="long" and a["confidence"]>0.55,a
    # regime-приор: в trend_up приор ta выше, чем в range
    a_trend=ta_analyze(up,regime="trend_up")
    a_range=ta_analyze(up,regime="range")
    assert a_trend["p"]>a_range["p"],(a_trend["p"],a_range["p"])
    # без свечей — INSUFFICIENT
    assert not ta_analyze([])["ok"]
    # conservative ослабляет
    ac=ta_analyze(up,conservative=True,regime="trend_up")
    assert ac["confidence"]<a["confidence"] and ac["p"]<a["p"]
    # flow: продавцы давят -> short
    snap={"parts":{"tape":{"ok":True,"cvd":-5.0,"delta_pct":-4.0,"price_change_pct":-0.5,"divergence":False,"n":500,"age_sec":3.0},
                   "book":{"ok":True,"imbalance_pct":-30.0}}}
    f=flow_analyze(snap,regime="range");assert f["ok"] and f["side"]=="short"
    # дивергенция -> flat
    snap_div={"parts":{"tape":{"ok":True,"cvd":4.0,"delta_pct":3.0,"price_change_pct":-0.4,"divergence":True,"n":500,"age_sec":3.0},
                       "book":{"ok":False}}}
    fd=flow_analyze(snap_div);assert fd["side"]=="flat" and "дивергенция" in fd["note"]
    # deriv с перцентилем (главное в v5)
    snap_d={"parts":{"deriv":{"ok":True,"funding_pct":0.08,"oi":68000.0}}}
    # funding 0.08 — 95-й перцентиль истории -> экстремум
    hist=[0.0]*29+[0.08]
    dd=deriv_analyze(snap_d,regime="range",funding_history=hist)
    assert dd["ok"] and dd["side"]=="short" and "персентиль" in dd["evidence"][0],dd
    # funding 0.08 без истории -> тоже short, но по порогу
    dd2=deriv_analyze(snap_d,regime="range")
    assert dd2["side"]=="short"
    # sentiment: Extreme Greed + LSR>1.4 -> short
    snap_s={"parts":{"fng":{"ok":True,"value":80,"delta3":5,"delta7":10,"classification":"Extreme Greed"},
                     "lsr":{"ok":True,"ratio":1.5,"long_pct":60.0,"short_pct":40.0}}}
    s=sentiment_analyze(snap_s,regime="range")
    assert s["ok"] and s["side"]=="short",s
    # Extreme Fear -> long
    snap_f={"parts":{"fng":{"ok":True,"value":15,"delta3":-5,"delta7":-8,"classification":"Extreme Fear"},
                     "lsr":{"ok":True,"ratio":0.5,"long_pct":33.0,"short_pct":67.0}}}
    s2=sentiment_analyze(snap_f,regime="range")
    assert s2["ok"] and s2["side"]=="long",s2
    # нейтральная толпа -> flat
    snap_n={"parts":{"fng":{"ok":True,"value":50,"delta3":0,"delta7":0,"classification":"Neutral"},
                     "lsr":{"ok":True,"ratio":1.0,"long_pct":50.0,"short_pct":50.0}}}
    assert sentiment_analyze(snap_n)["side"]=="flat"
    # без F&G и LSR — INSUFFICIENT
    assert not sentiment_analyze({"parts":{}})["ok"]
    # analyze_all + конфликт ta-long/flow-short
    allr=analyze_all(snap=snap,klines=up,regime="trend_up")
    assert allr["ta"]["side"]=="long" and allr["flow"]["side"]=="short"
    rv=analyze_all(snap=snap,klines=up,regime="trend_up",conservative={"flow"})
    assert rv["flow"]["confidence"]<allr["flow"]["confidence"]
    print("mm_analyst: OK")
if __name__=="__main__":
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("--selftest",action="store_true")
    ap.add_argument("--snap",help="JSON снапшота mm_live")
    ap.add_argument("--klines",help="CSV ts,o,h,l,c,v")
    ap.add_argument("--regime",default="unknown")
    g=ap.parse_args()
    if g.selftest: selftest()
    else:
        snap=json.load(open(g.snap)) if g.snap else None
        kl=None
        if g.klines:
            import csv
            with open(g.klines,encoding="utf-8",newline="") as fh:
                kl=[[float(x) for x in r[:6]] for r in list(csv.reader(fh))[1:] if r]
        import json; print(json.dumps(analyze_all(snap,kl,regime=g.regime),ensure_ascii=False,indent=1))
