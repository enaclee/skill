#!/usr/bin/env python3
"""Единый контракт записей между модулями. v5.0 — экосистема с обратной связью.

Отличия от v4.0:
- добавлен regime (фаза рынка) — влияет на приоры аналитиков;
- добавлен sentiment (толпа: F&G + LSR) как 4-й обязательный аналитик;
- decision хранит regime и p_hat_from_feedback для воспроизводимости;
- RECORD хранит regime и feedback_ts для замыкания контура.
"""
SCHEMA_VERSION="5.1"
# Снимок рынка: ts, символ, цена, производные метрики, грейд источников.
SNAPSHOT=["ts","symbol","price","funding_pct","oi","oi_pct_change","lsr","fng","fng_delta3","fng_delta7","grade","sources"]
# Свечной ряд: ts,open,high,low,close,volume (строка klines.csv, как в v4).
KLINE=["ts","open","high","low","close","volume"]
# Вердикт одного аналитика. ok=False -> INSUFFICIENT (HALT), оценок «на глаз» нет.
ANALYST=["module","ok","side","p","confidence","evidence","invalidate","note"]
# Классификация режима рынка (mm_regime). kind ∈ {trend_up,trend_down,range,volatile,unknown}.
REGIME=["kind","confidence","adx","atr_pct","bb_width_pct","note"]
# Решение совета (mm_council). status: AGREE | NO_TRADE | HALT | REVISIT.
# v5: regime и p_hat_from_feedback фиксируются в решении — это и есть контур обратной связи.
DECISION=["status","side","p","confidence","conflicts","audit","modules","regime","p_hat_from_feedback","note"]
# План сделки (mm_risk / mm_journal pre).
PLAN=["id","module","pair","side","entry","stop","tp1","p","lev","risk_usd"]
# Необязательные поля плана: funding_pct, n_funding, tp2, regime, horizon_h,
# council_status, council_side, council_note, p_hat.
# Запись журнала после выхода (mm_journal post).
RECORD=["id","ts","plan","exit","result_usd","R","compliant","error_code","scenario_hit","regime"]
# Гипотеза (mm_journal hyp_*).
HYPO=["id","ts","claim","evidence_for","evidence_against","p","status","outcome","brier","regime"]
# Аналитики, без которых сделка невозможна (HALT при INSUFFICIENT).
# v5: добавлен sentiment — толпа отдельным голосом, как и тренд/поток/деривативы.
MODULES_REQUIRED=("ta","flow","deriv","sentiment")
SIDES=("long","short","flat")
REGIMES=("trend_up","trend_down","range","volatile","unknown")
def validate(rec,fields):
    miss=[k for k in fields if k not in rec]
    return (not miss),miss
def selftest():
    ok,miss=validate({"ts":1,"symbol":"BTC"},SNAPSHOT)
    assert not ok and "price" in miss
    assert validate({k:0 for k in KLINE},KLINE)[0]
    a={"module":"ta","ok":True,"side":"flat","p":0.5,"confidence":0.0,"evidence":[],"invalidate":[],"note":""}
    assert validate(a,ANALYST)[0]
    r={"kind":"trend_up","confidence":0.7,"adx":28.0,"atr_pct":1.5,"bb_width_pct":2.0,"note":""}
    assert validate(r,REGIME)[0]
    d={"status":"AGREE","side":"long","p":0.58,"confidence":0.7,"conflicts":[],"audit":[],"modules":{},
       "regime":"trend_up","p_hat_from_feedback":None,"note":""}
    assert validate(d,DECISION)[0]
    assert MODULES_REQUIRED==("ta","flow","deriv","sentiment")
    assert set(REGIMES)>=set(["trend_up","range","volatile"])
    print("mm_schema: OK")
if __name__=="__main__": selftest()
