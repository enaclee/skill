#!/usr/bin/env python3
"""Сетевой клиент v5.0: общий бюджет времени, кэш, повтор, честный грейд.
В v4 здесь были баги: age_sec=None через `or 0` формально считался «свежим»;
здесь — явная обработка None: упавший источник НИКОГДА не свежий, и грейд честно D.

Контракт: fetch_json возвращает (payload, meta). meta всегда содержит source/attempts/error;
payload может быть None при полной неудаче. Кэш используется как fallback, но помечается."""
import hashlib,json,os,time,datetime,urllib.request,urllib.error
import mm_config
BASE=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","data")
CACHE=os.path.join(BASE,"cache");LOG=os.path.join(BASE,"errors.log")
def log_err(m):
    os.makedirs(BASE,exist_ok=True)
    with open(LOG,"a",encoding="utf-8") as f:
        f.write(json.dumps({"ts":datetime.datetime.now(datetime.timezone.utc).isoformat(),"m":m},ensure_ascii=False)+"\n")
def fetch_json(url,timeout=8,retries=2,user_agent="market-mind/5"):
    """Живой запрос с кэш-фallback. Никогда не бросает — возвращает (None, meta) при провале."""
    os.makedirs(CACHE,exist_ok=True)
    path=os.path.join(CACHE,hashlib.sha256(url.encode()).hexdigest()[:24]+".json")
    meta={"url":url,"fetched_at":None,"source":"live","attempts":0,"error":None}
    for a in range(retries+1):
        meta["attempts"]=a+1
        try:
            req=urllib.request.Request(url,headers={"User-Agent":user_agent})
            with urllib.request.urlopen(req,timeout=timeout) as r:
                pay=json.loads(r.read().decode("utf-8"))
            meta["fetched_at"]=time.time()
            with open(path,"w",encoding="utf-8") as f: json.dump({"meta":meta,"payload":pay},f)
            return pay,meta
        except Exception as e:
            meta["error"]=str(e)[:200];log_err({"url":url,"a":a+1,"e":meta["error"]})
            if a<retries: time.sleep(min(1.5**a,3.0))
    # кэш-fallback с честной пометкой
    if os.path.exists(path):
        try:
            with open(path,encoding="utf-8") as f: c=json.load(f)
            c["meta"]["source"]="cache"
            c["meta"]["age_sec"]=round(time.time()-(c["meta"]["fetched_at"] or 0),1) if c["meta"]["fetched_at"] else None
            c["meta"]["error"]=meta["error"]
            return c["payload"],c["meta"]
        except Exception: pass
    return None,meta
def age_fresh(meta,max_age):
    """Честная свежесть: None fetched_at -> (False, None) (упал = не свежий), в отличие от v4 (or 0).
    Всегда возвращает кортеж (is_fresh, age_sec_or_None)."""
    if not meta or not meta.get("fetched_at"): return False,None
    age=time.time()-meta["fetched_at"]
    return (age<=max_age),(round(age,1) if age>=0 else None)
def series_quality(rows):
    """Качество свечного ряда: нет дублей, упорядочен по ts, OHLC-инварианты, объём >=0."""
    if not rows: return {"n":0,"ok":False,"issues":["empty"]}
    ts=[r[0] for r in rows]
    dup=len(ts)-len(set(ts));ordered=all(ts[i]<ts[i+1] for i in range(len(ts)-1))
    diffs=[ts[i+1]-ts[i] for i in range(len(ts)-1)]
    import statistics
    step=statistics.median(diffs) if diffs else 0
    gaps=sum(1 for d in diffs if step and d>1.5*step)
    bad=sum(1 for r in rows if not (r[3]<=min(r[1],r[4]) and r[2]>=max(r[1],r[4]) and r[2]>=r[3] and r[5]>=0 and min(r[1:5])>0))
    return {"n":len(rows),"ok":dup==0 and ordered and bad==0,"dupes":dup,"unordered":not ordered,
            "gaps":gaps,"bad_ohlc":bad,"step":step}
def selftest():
    # возраст: None fetched_at -> не свежий (главный фикс v5)
    assert age_fresh({"fetched_at":None},60)[0] is False
    assert age_fresh({"fetched_at":time.time()-1},60)[0] is True
    assert age_fresh({"fetched_at":time.time()-120},60)[0] is False
    # качество ряда
    assert series_quality([[i,100,101,99,100,1] for i in range(10)])["ok"]
    q=series_quality([[0,100,101,99,100,1],[2,100,101,99,100,1],[2,100,101,99,100,1]])
    assert not q["ok"] and q["dupes"]==1
    # OHLC-инвариант: low>high невозможен
    bad=[[0,100,99,105,100,1]]  # high<low
    assert not series_quality(bad)["ok"]
    print("mm_data: OK")
if __name__=="__main__":
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("--selftest",action="store_true")
    g=ap.parse_args()
    if g.selftest: selftest()
    else: print("use --selftest")
