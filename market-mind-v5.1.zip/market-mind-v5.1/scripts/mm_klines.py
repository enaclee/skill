#!/usr/bin/env python3
"""Свечи v5.0: REST-загрузка klines из Binance USDT-M или Bybit v5 (публичные, без ключей),
с fallback на CSV. В v4 свечи можно было подать только вручную из CSV -> аналитик ta
часто падал в INSUFFICIENT/HALT. Здесь — две публичных биржи + локальный CSV.

Формат строки свечи: [ts_ms, open, high, low, close, volume]. Унифицирован для Binance/Bybit.
"""
import argparse,csv,json,os,time
import mm_data,mm_config
def from_binance(symbol="BTCUSDT",interval="1h",limit=300,timeout=8,cfg=None):
    """Binance USDT-M klines: /fapi/v1/klines. Возвращает список [ts_ms,o,h,l,c,v]."""
    c=cfg or mm_config.load()
    base=c.get("sources",{}).get("binance","https://fapi.binance.com")
    url="%s/fapi/v1/klines?symbol=%s&interval=%s&limit=%d"%(base,symbol,interval,limit)
    pay,_=mm_data.fetch_json(url,timeout=timeout)
    if not isinstance(pay,list): return None
    rows=[]
    for k in pay:
        try: rows.append([int(k[0]),float(k[1]),float(k[2]),float(k[3]),float(k[4]),float(k[5])])
        except (TypeError,ValueError,IndexError): continue
    return rows or None
def from_bybit(symbol="BTCUSDT",interval="60",limit=300,timeout=8,cfg=None):
    """Bybit v5 klines: /v5/market/kline. interval в минутах: '60'='1h'.
    Возвращает [ts_ms,o,h,l,c,v]; ts в секундах -> ms."""
    c=cfg or mm_config.load()
    base=c.get("sources",{}).get("bybit","https://api.bybit.com")
    url="%s/v5/market/kline?category=linear&symbol=%s&interval=%s&limit=%d"%(base,symbol,interval,limit)
    pay,_=mm_data.fetch_json(url,timeout=timeout)
    if not isinstance(pay,dict) or pay.get("retCode")!=0: return None
    lst=(pay.get("result") or {}).get("list") or []
    rows=[]
    for k in lst:  # Bybit возвращает в обратном порядке (новые сверху)
        try:
            rows.append([int(k[0])*1000,float(k[1]),float(k[2]),float(k[3]),float(k[4]),float(k[5])])
        except (TypeError,ValueError,IndexError): continue
    rows.reverse()
    return rows or None
def from_csv(path):
    """CSV: заголовок ts,open,high,low,close,volume; числа. Совместим с v4."""
    if not os.path.exists(path): return None
    with open(path,encoding="utf-8",newline="") as f:
        rows=[[float(x) for x in r[:6]] for r in list(csv.reader(f))[1:] if r and r[0] and r[0][0]!="#"]
    return rows or None
def fetch(symbol="BTCUSDT",interval="1h",limit=300,timeout=8,cfg=None,prefer="binance",csv_path=None):
    """Цепочка источников: prefer -> второй биржевый -> CSV (если указан).
    Возвращает (rows, source_name, quality). rows=None -> все источники упали."""
    c=cfg or mm_config.load()
    sources=[]
    if prefer=="bybit":
        sources=[("bybit",lambda: from_bybit(symbol,interval if interval.isdigit() else "60",limit,timeout,c)),
                 ("binance",lambda: from_binance(symbol,interval,limit,timeout,c))]
    else:
        sources=[("binance",lambda: from_binance(symbol,interval,limit,timeout,c)),
                 ("bybit",lambda: from_bybit(symbol,(interval if interval.isdigit() else "60"),limit,timeout,c))]
    for name,fn in sources:
        rows=fn()
        if rows and len(rows)>=2:
            q=mm_data.series_quality(rows)
            if q["ok"]: return rows,name,q
    if csv_path:
        rows=from_csv(csv_path)
        if rows:
            q=mm_data.series_quality(rows)
            return rows,"csv",q
    return None,"none",{"ok":False,"n":0,"issues":["all_sources_failed"]}
def selftest():
    # from_csv: нет файла -> None
    assert from_csv("/nonexistent.csv") is None
    # парсинг валидного CSV-содержимого (через временный файл)
    import tempfile
    with tempfile.NamedTemporaryFile("w",suffix=".csv",delete=False,encoding="utf-8",newline="") as f:
        f.write("ts,open,high,low,close,volume\n")
        for i in range(220):
            f.write("%d,%.4f,%.4f,%.4f,%.4f,1.0\n"%(i,100+i*0.01,101+i*0.01,99+i*0.01,100+i*0.01))
        path=f.name
    rows=from_csv(path)
    assert rows and len(rows)==220 and rows[0][1]==100.0
    os.unlink(path)
    # унификация ts: Bybit-формат (секунды -> ms) должен дать int ts_ms
    # симулируем парсинг списка как от Bybit
    fake_bybit=[[1000,"100","101","99","100.5","1"],[900,"100","101","99","100","1"]]
    rows=[]
    for k in fake_bybit:
        rows.append([int(k[0])*1000,float(k[1]),float(k[2]),float(k[3]),float(k[4]),float(k[5])])
    rows.reverse()
    assert rows[0][0]==900000 and rows[1][0]==1000000
    # fallback: при пустом первом источнике идём ко второму (через mock).
    # Патчим по имени модуля: при запуске как __main__ используем sys.modules.
    import unittest.mock as mock, sys
    mod_name=__name__
    with mock.patch("%s.from_binance"%mod_name,return_value=None),\
         mock.patch("%s.from_bybit"%mod_name,return_value=[[i*3600000,100,101,99,100,1] for i in range(300)]):
        r,src,q=fetch("BTCUSDT",prefer="binance")
        assert src=="bybit" and q["ok"] and len(r)==300,(src,q.get("ok"),len(r) if r else 0)
    print("mm_klines: OK")
if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--selftest",action="store_true")
    ap.add_argument("--symbol",default="BTCUSDT")
    ap.add_argument("--interval",default="1h")
    ap.add_argument("--limit",type=int,default=300)
    ap.add_argument("--prefer",choices=["binance","bybit"],default="binance")
    ap.add_argument("--csv",help="fallback CSV")
    ap.add_argument("--out",help="записать в JSON [ts_ms,o,h,l,c,v]")
    g=ap.parse_args()
    if g.selftest: selftest()
    else:
        rows,src,q=fetch(g.symbol,g.interval,g.limit,prefer=g.prefer,csv_path=g.csv)
        print(json.dumps({"source":src,"quality":q,"n":(len(rows) if rows else 0)},ensure_ascii=False,indent=1))
        if g.out and rows:
            with open(g.out,"w",encoding="utf-8") as f: json.dump(rows,f)
