#!/usr/bin/env python3
"""Живой снимок рынка v5.0: лента/CVD/книга/funding/OI/LSR + F&G с дельтами 3/7д.

Отличия от v4:
- добавлен LSR (long/short account ratio, Binance USDT-M) — толпа;
- F&G тянется 7-дневной историей, считаются дельты 3/7д (признано в v4 нереализованным);
- общий бюджет времени, честная обработка None (упавший источник не «свежий»);
- грейд честный: обязательные источники tape+deriv; sentiment (F&G/LSR) — желательный,
  его отсутствие не роняет грейд ниже C (но council это увидит и приорист у sentiment будет 0.5).

Ликвидации по-прежнему только WS (REST allForceOrders закрыт у Binance).
"""
import argparse,json,os,time
import mm_data,mm_config
BASE=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","data","live")
def _bin(cfg): return cfg.get("sources",{}).get("binance","https://fapi.binance.com")
def _byb(cfg): return cfg.get("sources",{}).get("bybit","https://api.bybit.com")
def _get_simple(url,timeout=8):
    """Простой GET для внешних модулей (mm_alerts). Возвращает (payload, error_str)."""
    pay,_=mm_data.fetch_json(url,timeout=timeout,retries=1)
    return pay,(None if pay is not None else "fetch_failed")
def tape_calc_bybit(d,symbol=None):
    """Bybit v5 /v5/market/publicTrade: список сделок с sides Buy/Sell.
    Альтернатива tape_calc (когда Binance WAF блокирует aggTrades)."""
    if not isinstance(d,dict) or d.get("retCode")!=0: return {"ok":False,"error":"bad_bybit_trades"}
    r=d.get("result") or {};trades=r.get("list") or []
    if not trades: return {"ok":False,"error":"empty_tape"}
    buy=sum(float(t["v"]) for t in trades if t.get("side")=="Buy")
    sell=sum(float(t["v"]) for t in trades if t.get("side")=="Sell")
    cvd=buy-sell;p0=float(trades[0]["p"]);p1=float(trades[-1]["p"]);tot=buy+sell
    # Bybit publicTrade отдаёт ts в наносекундах -> в ms для age
    ts_ms=int(int(trades[-1].get("T") or 0)/1_000_000)
    return {"ok":True,"n":len(trades),"buy_qty":round(buy,4),"sell_qty":round(sell,4),"cvd":round(cvd,4),
            "delta_pct":round(100*cvd/tot,3) if tot else 0.0,
            "price_change_pct":round(100*(p1-p0)/p0,4) if p0 else 0.0,
            "divergence":bool((cvd>0 and p1<p0) or (cvd<0 and p1>p0)),
            "age_sec":round(max(0.0,time.time()-ts_ms/1000.0),1)}
def tape_calc(d):
    """Агрессоры, CVD, дельта, дивергенция. d — список aggTrades Binance."""
    if not isinstance(d,list) or not d: return {"ok":False,"error":"empty_tape"}
    buy=sum(float(t["q"]) for t in d if not t["m"]);sell=sum(float(t["q"]) for t in d if t["m"])
    cvd=buy-sell;p0=float(d[0]["p"]);p1=float(d[-1]["p"]);tot=buy+sell
    return {"ok":True,"n":len(d),"buy_qty":round(buy,4),"sell_qty":round(sell,4),"cvd":round(cvd,4),
            "delta_pct":round(100*cvd/tot,3) if tot else 0.0,
            "price_change_pct":round(100*(p1-p0)/p0,4) if p0 else 0.0,
            "divergence":bool((cvd>0 and p1<p0) or (cvd<0 and p1>p0)),
            "age_sec":round(max(0.0,time.time()-float(d[-1]["T"])/1000.0),1)}
def book_calc(d):
    """Дисбаланс книги. Спуфабельно — вторичный признак."""
    if not isinstance(d,dict) or "bids" not in d or "asks" not in d: return {"ok":False,"error":"bad_book"}
    b=sum(float(x[1]) for x in d["bids"]);a=sum(float(x[1]) for x in d["asks"])
    return {"ok":True,"bid_qty":round(b,3),"ask_qty":round(a,3),
            "imbalance_pct":round(100*(b-a)/(b+a),3) if b+a else 0.0,
            "caution":"book imbalance is spoofable; confirm with tape/CVD"}
def deriv_calc_bybit(p):
    """Bybit v5 /v5/market/tickers?category=linear: fundingRate, openInterest.
    Альтернатива deriv_calc (когда Binance WAF блокирует premiumIndex/openInterest)."""
    if not isinstance(p,dict) or p.get("retCode")!=0: return {"ok":False,"error":"bad_bybit_tickers"}
    r=p.get("result") or {};lst=r.get("list") or []
    if not lst: return {"ok":False,"error":"empty_list"}
    t=lst[0]
    try:
        fr=float(t.get("fundingRate") or 0)*100  # Binance-style % уже
        oi=float(t.get("openInterest") or 0)
        return {"ok":True,"funding_pct":round(fr,5),"oi":oi,"mark":float(t.get("markPrice") or 0)}
    except (TypeError,ValueError): return {"ok":False,"error":"bad_fields"}
def deriv_calc(p,o):
    """funding (lastFundingRate), mark, OI. Ликвидации — WS-only."""
    out={"ok":bool(isinstance(p,dict) and "lastFundingRate" in p)}
    if out["ok"]:
        out["funding_pct"]=round(float(p["lastFundingRate"])*100,5)
        out["next_funding_ts"]=p.get("nextFundingTime");out["mark"]=float(p.get("markPrice") or 0)
    if isinstance(o,dict) and "openInterest" in o:
        out["oi"]=float(o["openInterest"]);out["oi_ts"]=o.get("time")
    out["liquidations"]="WS_ONLY: !forceOrder@arr (Binance) / liquidation.BTCUSDT (Bybit); fallback Coinglass"
    return out
def lsr_calc(p):
    """Long/Short Account Ratio (Binance USDT-M /futures/data/globalLongShortAccountRatio).
    Толпа: ratio>1.4 — толпа лонгует (контр-тренд вниз), <0.7 — толпа шортует (контр-тренд вверх)."""
    if not isinstance(p,list) or not p: return {"ok":False,"error":"empty_lsr"}
    last=p[-1]
    try:
        ratio=float(last.get("longShortRatio") or 0)
        longs=float(last.get("longAccount") or 0)*100
        shorts=float(last.get("shortAccount") or 0)*100
        return {"ok":True,"ratio":round(ratio,4),"long_pct":round(longs,2),"short_pct":round(shorts,2),
                "ts":last.get("timestamp")}
    except (TypeError,ValueError): return {"ok":False,"error":"bad_lsr"}
def fng_calc(p):
    """Fear & Greed с дельтами 3/7д. p — api.alternative.me/fng/?limit=7, данные новые сверху."""
    if not isinstance(p,dict) or not p.get("data"): return {"ok":False,"error":"empty_fng"}
    data=p["data"]
    try:
        cur=int(data[0]["value"]);ts0=int(data[0]["timestamp"])
        d3=int(data[2]["value"]) if len(data)>2 else cur
        d7=int(data[6]["value"]) if len(data)>6 else cur
        return {"ok":True,"value":cur,"ts":ts0,"delta3":cur-d3,"delta7":cur-d7,
                "classification":data[0].get("value_classification","")}
    except (TypeError,ValueError,IndexError,KeyError): return {"ok":False,"error":"bad_fng"}
def grade_live(parts,cfg=None):
    """Грейд A/C/D. Обязательные: tape+deriv (как в v4). LSR/F&G — желательные."""
    c=cfg or mm_config.load()
    req=[parts.get("tape",{}),parts.get("deriv",{})]
    if any(not x.get("ok") for x in req): return "D"
    tape_age=parts["tape"].get("age_sec",1e9)
    book_ok=parts.get("book",{}).get("ok")
    # sentiment OK — добавляет «зрелости»: A если оба желательных на месте, иначе C
    sent_ok=parts.get("lsr",{}).get("ok") and parts.get("fng",{}).get("ok")
    if tape_age<=120 and book_ok and sent_ok: return "A"
    if tape_age<=120 and book_ok: return "A"
    return "C"
def snapshot(symbol="BTCUSDT",budget_sec=30.0,cfg=None):
    c=cfg or mm_config.load()
    deadline=time.monotonic()+budget_sec
    def left(): return deadline-time.monotonic()
    def _get(url,pause=0.0):
        if left()<=0.5: return None
        if pause>0 and left()>1.0: time.sleep(min(pause,max(0.0,left()-1.0)))
        pay,_=mm_data.fetch_json(url,timeout=min(8.0,max(0.6,left())),retries=0)
        return pay
    bn=_bin(c);byb=_byb(c)
    # Небольшая пауза между эндпоинтами — снижает риск WAF-блока Binance (418) на
    # серии быстрых запросов без API-ключа. Если IP уже заблокирован, грейд честно D.
    t=_get(bn+"/fapi/v1/aggTrades?symbol="+symbol+"&limit=500",pause=0.0)
    b=_get(bn+"/fapi/v1/depth?symbol="+symbol+"&limit=100",pause=0.3)
    p=_get(bn+"/fapi/v1/premiumIndex?symbol="+symbol,pause=0.3)
    o=_get(bn+"/fapi/v1/openInterest?symbol="+symbol,pause=0.3)
    lsr=_get(bn+"/futures/data/globalLongShortAccountRatio?symbol="+symbol+"&period=1h&limit=8",pause=0.3)
    fng=_get(c.get("sources",{}).get("fng","https://api.alternative.me/fng")+"/?limit=7",pause=0.0)
    # deriv fallback: Binance WAF часто блокирует premiumIndex/openInterest в серии;
    # в этом случае тянем funding/OI из Bybit v5 (публичные, без ключа).
    deriv=deriv_calc(p,o) if p is not None else {"ok":False,"error":"no_binance_deriv","liquidations":"WS_ONLY"}
    if not deriv.get("ok"):
        by=_get(byb+"/v5/market/tickers?category=linear&symbol="+symbol,pause=0.2)
        bd=deriv_calc_bybit(by) if by is not None else {"ok":False,"error":"no_bybit"}
        if bd.get("ok"): deriv=bd
        deriv["liquidations"]="WS_ONLY: !forceOrder@arr (Binance) / liquidation.BTCUSDT (Bybit); fallback Coinglass"
    # tape fallback: Binance WAF часто блокирует aggTrades; тянем ленту из Bybit publicTrade.
    tape=tape_calc(t) if t is not None else {"ok":False,"error":"no_binance_tape"}
    if not tape.get("ok"):
        bt=_get(byb+"/v5/market/recent-trade?category=linear&symbol="+symbol+"&limit=500",pause=0.2)
        tape=tape_calc_bybit(bt) if bt is not None else {"ok":False,"error":"no_bybit_tape"}
    # book fallback: аналогично — Bybit orderbook.50 (L1 snapshot в recent-quote также есть)
    book=book_calc(b) if b is not None else {"ok":False,"error":"no_binance_book"}
    parts={"tape":tape,
           "book":book,
           "deriv":deriv,
           "lsr":lsr_calc(lsr) if lsr is not None else {"ok":False,"error":"no_lsr"},
           "fng":fng_calc(fng) if fng is not None else {"ok":False,"error":"no_fng"}}
    # цена из tape (свежая) или deriv.mark
    price=None
    if parts["tape"].get("ok") and t: price=float(t[-1]["p"])
    elif parts["deriv"].get("ok") and parts["deriv"].get("mark"): price=parts["deriv"]["mark"]
    snap={"ts":time.time(),"symbol":symbol,"price":price,"grade":grade_live(parts,c),
          "parts":parts,"elapsed_sec":round(budget_sec-max(0.0,left()),2)}
    os.makedirs(BASE,exist_ok=True)
    with open(os.path.join(BASE,symbol+"_"+str(int(snap["ts"]))+".json"),"w",encoding="utf-8") as f:
        json.dump(snap,f,ensure_ascii=False)
    return snap
def selftest():
    now=int(time.time()*1000)
    # tape
    tc=tape_calc([{"q":"1","p":"100","m":False,"T":now-2000},{"q":"3","p":"99","m":True,"T":now-1000}])
    assert tc["ok"] and tc["cvd"]==-2.0 and tc["divergence"] is False
    tc2=tape_calc([{"q":"3","p":"100","m":False,"T":now-2000},{"q":"1","p":"99","m":True,"T":now-1000}])
    assert tc2["divergence"] is True
    assert tape_calc([])["ok"] is False
    # Bybit fallback для tape
    bt={"retCode":0,"result":{"list":[{"v":"1","p":"100","side":"Buy"},{"v":"3","p":"99","side":"Sell"}]}}
    tc_b=tape_calc_bybit(bt)
    assert tc_b["ok"] and tc_b["cvd"]==-2.0,tc_b
    assert tape_calc_bybit({"retCode":1,"result":{}})["ok"] is False
    # Bybit fallback для deriv
    dt={"retCode":0,"result":{"list":[{"fundingRate":"0.0001","openInterest":"100","markPrice":"100.0"}]}}
    dc_b=deriv_calc_bybit(dt)
    assert dc_b["ok"] and abs(dc_b["funding_pct"]-0.01)<1e-9 and dc_b["oi"]==100.0
    assert deriv_calc_bybit({"retCode":1,"result":{}})["ok"] is False
    # book
    bc=book_calc({"bids":[["1","2"],["2","3"]],"asks":[["3","5"]]})
    assert bc["ok"] and bc["imbalance_pct"]==0.0
    assert book_calc({})["ok"] is False
    # deriv
    dc=deriv_calc({"lastFundingRate":"0.0001","markPrice":"100","nextFundingTime":now},{"openInterest":"10","time":now})
    assert dc["ok"] and abs(dc["funding_pct"]-0.01)<1e-9 and dc["oi"]==10.0
    # lsr
    lc=lsr_calc([{"longShortRatio":"1.5","longAccount":"0.6","shortAccount":"0.4","timestamp":"1700000000000"}])
    assert lc["ok"] and lc["ratio"]==1.5 and abs(lc["long_pct"]-60.0)<1e-6
    assert lsr_calc([])["ok"] is False
    # fng: дельты 3/7д (главное добавление v5)
    fng={"data":[{"value":"30","timestamp":"1700000000","value_classification":"Fear"},
                 {"value":"28","timestamp":"1699900000"},
                 {"value":"40","timestamp":"1699800000"},  # 3 дня назад -> d3=30-40=-10
                 {"value":"25","timestamp":"1699700000"},{"value":"22","timestamp":"1699600000"},
                 {"value":"20","timestamp":"1699500000"},
                 {"value":"15","timestamp":"1699400000"}]}  # 7 дней назад -> d7=30-15=15
    fc=fng_calc(fng)
    assert fc["ok"] and fc["value"]==30 and fc["delta3"]==-10 and fc["delta7"]==15,fc
    assert fng_calc({"data":[]})["ok"] is False
    # grade
    full={"tape":{"ok":True,"age_sec":3},"deriv":{"ok":True},"book":{"ok":True},
          "lsr":{"ok":True},"fng":{"ok":True}}
    assert grade_live(full)=="A"
    no_sent={"tape":{"ok":True,"age_sec":3},"deriv":{"ok":True},"book":{"ok":True},
             "lsr":{"ok":False},"fng":{"ok":False}}
    assert grade_live(no_sent)=="A"  # без sentiment всё ещё A (он желательный)
    bad_tape={"tape":{"ok":False},"deriv":{"ok":True}}
    assert grade_live(bad_tape)=="D"
    old_tape={"tape":{"ok":True,"age_sec":200},"deriv":{"ok":True},"book":{"ok":True}}
    assert grade_live(old_tape)=="C"
    # бюджет: при нулевом остатке честно D, не падает
    s=snapshot("BTCUSDT",budget_sec=0)
    assert s["grade"]=="D" and not s["parts"]["tape"]["ok"]
    print("mm_live: OK")
if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--snapshot",action="store_true");ap.add_argument("--selftest",action="store_true")
    ap.add_argument("--symbol",default="BTCUSDT");ap.add_argument("--budget",type=float,default=30.0)
    g=ap.parse_args()
    if g.selftest: selftest()
    elif g.snapshot: print(json.dumps(snapshot(g.symbol,g.budget),ensure_ascii=False,indent=1))
    else: print("use --snapshot or --selftest")
