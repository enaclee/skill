Рабочие данные (создаются скриптами автоматически):
  cache/           кэш ответов API (mm_data.py)
  errors.log       журнал ошибок запросов (mm_data.py)
  live/            снимки ленты/книги/funding/OI/LSR/F&G (mm_live.py)
  journal.csv      журнал сделок (mm_journal.py); v5: council_status/side/note + regime + p_hat
  hypotheses.csv   журнал гипотез (mm_journal.py)
  klines.csv       свечи для бэктеста и ta; в v5 можно подать через --csv или грузить REST
                   (ts_ms,open,high,low,close,volume — заголовок обязателен)
  config.json      лимиты ворот, комиссии, приоры по режимам, источники (необязательный)
  alerts.json      правила алертов, образец alerts.example.json (mm_alerts.py)
  state/           risk.json (вердикты дня), alerts.json (что уже сработало)

v5.0: конфигурация иерархическая: DEFAULTS (mm_config.DEFAULTS) <- data/config.json <- env MM5_*.
     Комиссии настраиваемые (mm_config.fees): Bybit VIP0 / Binance tier0 по умолчанию,
     можно поднять под свой VIP-уровень в data/config.json (см. config.example.json).
