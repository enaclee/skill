# SKILL PATCH v5.0

Архитектура: Рынок -> Ingestion -> Regime -> Analysis (4) -> Cross-Validation -> Decision -> Risk Gate -> Output.
Контур обратной связи: Journal -> Feedback p_hat -> Council (приоры).

1. p = regime-приор (mm_config.PRIORS_BY_REGIME) + 0.025×сила сигнала; зажат в [0.5, 0.8].
   При `use_feedback_prior=True` и n_compliant >= 20 приор аккуратно корректируется через
   p_hat (±0.05). При n_compliant < 20 — LOW CONFIDENCE, вердикта об эдже нет.
   Статус: regime-приоры в mm_config.PRIORS_BY_REGIME, корректировка в mm_council._adjust_prior.
2. Пороги динамические по режимам (РЕАЛИЗОВАНО в v5):
   - funding: перцентиль за 30д (deriv_analyze(funding_history=...)) — 95/5 перцентиль;
     без истории — fallback на порог ±funding_extreme_pct (0.05).
   - F&G: контекст (Extreme Greed/Fear) + дельта 3/7д (mm_live.fng_calc);
   - LSR: long/short account ratio, пороги lsr_extreme=1.4 / lsr_low=0.7 (mm_config).
   - regime: classify по ADI-proxy + ATR%/BB-ширина (mm_regime).
   beta и корреляции rolling 30/60/90д — пока НЕ реализованы.
3. Контракт документация-код: метрика заявляется только если есть функция.
   winrate/PF/expectancy/maxDD/sharpe/sortino/recovery -> mm_backtest.metrics
   Brier/calibration -> mm_journal.stats; p_hat/regime_p_hat -> mm_feedback
   quality/grade -> mm_data/mm_live; costs/risk/liq -> mm_core (с настраиваемыми комиссиями)
   regime/adx/atr_pct/bb_width_pct -> mm_regime
   tape/CVD/book/funding/OI/LSR/F&G(дельты 3/7д) -> mm_live
   вердикты модулей ta/flow/deriv/sentiment -> mm_analyst
   AGREE/NO_TRADE/HALT/REVISIT, конфликты, audit, regime, p_hat_from_feedback -> mm_council
   gates PASS/BLOCK, отпечаток плана -> mm_risk; алерты цена/funding -> mm_alerts
   edge_by_regime -> mm_journal.stats; klines REST Binance/Bybit -> mm_klines
4. Отчёт = 20 пунктов ТЗ; при нехватке данных пункт помечается INSUFFICIENT.
   Статус: генератора отчёта в коде нет, формируется вручную.
5. Риск-менеджмент аналитический: не открывает и не закрывает реальные сделки.
6. Издержки: слиппедж по сторонам, funding со знаком, риск включает издержки.
   C — ожидаемые (funding со знаком), C_worst — худший случай (льготы не засчитываются).
   Эталон: стоп 0.8%, цель 2.2%, C=0.176% -> проходит фильтры.
   Регрессия: стоп 0.7%, цель 2.0% -> обязана отклоняться по лимиту издержек.
   Оба случая в mm_core.selftest; регрессия дополнительно в mm_risk.selftest.
   v5.0: комиссии настраиваемые (mm_config.fees, data/config.json, env MM5_*).
7. Ворота перед сделкой (mm_risk): формат, экономика (4 фильтра mm_core), размер с минимальным лотом,
   риск на сделку, маржа, буфер ликвидации, плечо, дубли, число открытых позиций, сделок и убыток за день.
   Право вето: decision NO_TRADE/HALT -> BLOCK; сторона плана != стороне совета -> BLOCK;
   data_grade D -> BLOCK; grade C требует p >= min_p_grade_c (0.6).
   BLOCK окончателен: модуль не правит план и не ослабляет лимиты.
   mm_journal pre --require-gate принимает только план с PASS за сегодня; вердикт привязан к отпечатку.
   Отпечаток нормализует lev по умолчанию (план без lev и с lev=default — один отпечаток).
   Лимиты по умолчанию: депозит 100 USD, риск 2%, маржа 50%, буфер ≥3 стопов, 1 открытая позиция,
   3 сделки и убыток 3% в день (меняются в data/config.json или env MM5_*).
8. Алерты (mm_alerts, 24/7): above/below/stop/target, pct_move к цене 24ч назад, funding_above/below.
   stop/target принимают side: стоп лонга срабатывает снизу, стоп шорта — сверху; без side — старое поведение.
   Каждое правило звонит один раз (rearm по желанию). Перцентиль funding теперь в deriv_analyze.
   Результат дня в mm_risk считается по сделкам, открытым сегодня.
9. Cross-Validation (mm_council): конфликт long/short при обеих conf >= 0.6 -> REVISIT слабейшего
   (conservative: conf x0.7, p к нейтрали); повторный конфликт -> NO_TRADE (CONFLICT).
   Мягкий конфликт: слабая сторона отброшена с записью в audit. Все flat -> NO TRADE.
   Обязательный модуль INSUFFICIENT -> HALT. p_agg взвешенная по confidence, 0.5-0.8.
   v5.0: 4 модуля (ta/flow/deriv/sentiment). regime-приоры. feedback p_hat (±0.05 корректировка).
   Параметры: min_conf 0.5, conflict_min_conf 0.6, max_revisits 1 (config.json).
10. Regime (mm_regime) — НОВОЕ в v5: классифицирует фазу trend_up/trend_down/range/volatile/unknown
    по свечному ряду (DI-proxy для трендовой силы, ATR%/BB-ширина для волатильности).
    Влияет на приоры аналитиков через mm_config.prior_for(module, regime).
11. Sentiment (mm_analyst.sentiment_analyze) — НОВОЕ в v5: толпа = F&G + LSR.
    Extreme Greed (>=75) или LSR >= 1.4 -> short (контр-тренд).
    Extreme Fear (<=25) или LSR <= 0.7 -> long (контр-тренд).
    F&G дельта 3д |Δ| >= 15 усиливает разворот. Контр-трендовая логика = психология рынка.
    Обязательный модуль (HALT при INSUFFICIENT) — без F&G и LSR анализ останавливается.
12. Live klines REST (mm_klines) — НОВОЕ в v5: /fapi/v1/klines (Binance) и /v5/market/kline (Bybit),
    fallback на CSV. Унифицированный формат [ts_ms, o, h, l, c, v].
13. Binance WAF fallback (mm_live) — НОВОЕ в v5: при HTTP 418 на aggTrades/premiumIndex/openInterest
    mm_live переключается на Bybit v5 (publicTrade/recent-trade для tape, tickers для funding+OI).
    Jitter 0.3с между эндпоинтами снижает риск блока. Грейд D честно отражает «нет данных».
