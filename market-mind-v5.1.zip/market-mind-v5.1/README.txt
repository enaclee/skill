MARKET-MIND v5.1 (Ecosystem with Feedback Loop)

Архитектура (цепочка А→Б):
  Рынок -> Ingestion -> Regime -> 4 Аналитика -> Council -> Risk Gate -> Output
                                                              |
                                                              v
                              Journal -> Feedback p_hat -> (обратно в Council)

4 аналитика — НЕЗАВИСИМЫЕ голоса (ta/flow/deriv/sentiment), совет проверяет их выводы
друг против друга, конфликт -> пересмотр -> NO TRADE, Risk Gate имеет право вето.
Regime (фаза рынка) влияет на приоры аналитиков — «психология фазы». sentiment (толпа)
смотрит на F&G и LSR — это и есть психология рынка. После 20 compliant-сделок p_hat
из журнала корректирует приоры — контур замкнут.

Запуск (только стандартная библиотека Python; проверено на Python 3.12):
  python tests/run_tests.py            -> ALL PASS (14 selftest + 7 интеграций)
  python scripts/mm_live.py --snapshot -> живой срез ленты/книги/funding/OI/LSR/F&G
                                          (Binance WAF -> fallback Bybit v5)
  python scripts/mm_klines.py --symbol BTCUSDT --interval 1h --limit 300
                                       -> REST klines (Binance или Bybit), fallback --csv
  python scripts/mm_regime.py --klines data/klines.csv
                                       -> классификация фазы (trend_up/down/range/volatile)
  python scripts/mm_analyst.py --snap live/BTCUSDT_*.json --klines data/klines.csv --regime trend_up
  python scripts/mm_council.py --decide --snap <snap.json> --klines <klines.csv> [--regime trend_up] [--json]
  python scripts/mm_core.py --price 73700 --stop 0.8 --target 2.2 --risk 1.5
  python scripts/mm_risk.py check '<план>' [--decision council.json] [--grade A|C|D] -> PASS/BLOCK
  python scripts/mm_journal.py pre '<план>' --require-gate -> запись только с PASS за сегодня
  python scripts/mm_journal.py post '<итог>' -> результат с exit/result_usd/regime
  python scripts/mm_journal.py stats -> edge + edge_by_regime + calibration + Brier
  python scripts/mm_feedback.py --report -> p_hat + edge по режимам (контур обратной связи)
  python scripts/mm_backtest.py --csv data/klines.csv [--council] [--regime-aware]
  python scripts/mm_backtest.py --demo 6000 --windows 4   # синтетика, помечается SYNTHETIC
  python scripts/mm_alerts.py add --symbol BTCUSDT --stop 73000 --side long
  python scripts/mm_alerts.py check

Состав:
  scripts/   mm_schema, mm_config, mm_data, mm_klines, mm_live, mm_regime, mm_analyst,
             mm_council, mm_core, mm_risk, mm_journal, mm_feedback, mm_backtest, mm_alerts
  SKILL.md   описание навыка (триггеры, архитектура, поток, правила)
  tests/     run_tests.py (14 selftest + 7 интеграций экосистемы)
  data/      рабочие данные, создаются при запуске (см. data/README.txt)
  SOURCES_LIVE.md  источники живых данных и их ограничения (включая Binance WAF)
  SKILL_PATCH.md   правила и контракт документация-код (v5.0→v5.1)

Пример цепочки (конфликт):
  TA-long + Flow-short + Sentiment-short -> совет: NO_TRADE (CONFLICT) -> ворота: BLOCK.
Пример цепочки (согласие):
  TA-long + Flow-long + Deriv-flat + Sentiment-flat -> совет: AGREE long p~0.61 (regime=trend_up)
                                              -> ворота: PASS (лот/риск/маржа) -> журнал pre.
Пример цепочки (psychology):
  F&G=82 Extreme Greed + LSR=1.6 (толпа лонгует) + Deriv-flat + TA-flat в range
       -> sentiment short, deriv flat, ta flat, flow flat -> совет: AGREE short
       (толпа перегрета -> контр-тренд). Ворота проверяют экономику.

Риск-модуль аналитический: реальные ордера не открывает и не закрывает.
